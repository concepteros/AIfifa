App({
  globalData: {
    appName: "CheckFIFA"
  }
});
